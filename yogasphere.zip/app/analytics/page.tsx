"use client"

import { useState } from "react"
import { Navbar } from "@/components/navigation/navbar"
import { Footer } from "@/components/navigation/footer"
import { HealthCharts } from "@/components/analytics/health-charts"
import { HealthInsights } from "@/components/analytics/health-insights"
import { ExportData } from "@/components/analytics/export-data"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { BarChart3, TrendingUp, Heart, Activity, Zap, RefreshCw, Settings } from "lucide-react"

export default function AnalyticsPage() {
  const [lastUpdated, setLastUpdated] = useState(new Date())

  const handleRefresh = () => {
    setLastUpdated(new Date())
    // In a real app, this would fetch fresh data
  }

  const quickStats = [
    {
      label: "Avg Heart Rate",
      value: "72",
      unit: "bpm",
      change: "+2%",
      trend: "up",
      icon: Heart,
      color: "text-red-500",
    },
    {
      label: "Breathing Rate",
      value: "16",
      unit: "/min",
      change: "-5%",
      trend: "down",
      icon: Activity,
      color: "text-blue-500",
    },
    {
      label: "Stress Level",
      value: "35",
      unit: "%",
      change: "+8%",
      trend: "up",
      icon: Zap,
      color: "text-yellow-500",
    },
    {
      label: "Sessions",
      value: "24",
      unit: "this month",
      change: "+12%",
      trend: "up",
      icon: BarChart3,
      color: "text-green-500",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Navbar />

      <main className="pt-20 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-serif font-bold text-foreground mb-2">Health Analytics</h1>
                <p className="text-muted-foreground">
                  Comprehensive tracking of your wellness journey with real-time insights
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <Badge variant="secondary">
                  Last updated: {lastUpdated.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
                </Badge>
                <Button variant="outline" size="sm" onClick={handleRefresh}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh
                </Button>
                <Button variant="outline" size="sm">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {quickStats.map((stat, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{stat.label}</p>
                      <div className="flex items-baseline space-x-1">
                        <span className="text-2xl font-bold">{stat.value}</span>
                        <span className="text-sm text-muted-foreground">{stat.unit}</span>
                      </div>
                    </div>
                    <stat.icon className={`w-8 h-8 ${stat.color}`} />
                  </div>
                  <div className="flex items-center mt-2">
                    <TrendingUp className={`w-3 h-3 mr-1 ${stat.trend === "up" ? "text-green-500" : "text-red-500"}`} />
                    <span className={`text-xs ${stat.trend === "up" ? "text-green-500" : "text-red-500"}`}>
                      {stat.change} from last week
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Main Content */}
          <Tabs defaultValue="charts" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="charts">Charts & Trends</TabsTrigger>
              <TabsTrigger value="insights">Insights & Goals</TabsTrigger>
              <TabsTrigger value="export">Export & Share</TabsTrigger>
            </TabsList>

            <TabsContent value="charts">
              <HealthCharts />
            </TabsContent>

            <TabsContent value="insights">
              <HealthInsights />
            </TabsContent>

            <TabsContent value="export">
              <ExportData />
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  )
}
