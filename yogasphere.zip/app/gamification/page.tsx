"use client"

import { Navbar } from "@/components/navigation/navbar"
import { Footer } from "@/components/navigation/footer"
import { UserProgress } from "@/components/gamification/user-progress"
import { Challenges } from "@/components/gamification/challenges"
import { Badges } from "@/components/gamification/badges"
import { Leaderboard } from "@/components/gamification/leaderboard"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Trophy, Target, Award, Settings, Gift } from "lucide-react"

export default function GamificationPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Navbar />

      <main className="pt-20 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-serif font-bold text-foreground mb-2">Gamification Hub</h1>
                <p className="text-muted-foreground">
                  Track your progress, complete challenges, and compete with the community
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <Gift className="w-3 h-3" />
                  <span>Daily Bonus Available</span>
                </Badge>
                <Button variant="outline" size="sm">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Sidebar - User Progress */}
            <div className="lg:col-span-1">
              <UserProgress />
            </div>

            {/* Main Content Area */}
            <div className="lg:col-span-2">
              <Tabs defaultValue="challenges" className="space-y-6">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="challenges" className="flex items-center space-x-2">
                    <Target className="w-4 h-4" />
                    <span>Challenges</span>
                  </TabsTrigger>
                  <TabsTrigger value="badges" className="flex items-center space-x-2">
                    <Award className="w-4 h-4" />
                    <span>Badges</span>
                  </TabsTrigger>
                  <TabsTrigger value="leaderboard" className="flex items-center space-x-2">
                    <Trophy className="w-4 h-4" />
                    <span>Leaderboard</span>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="challenges">
                  <Challenges />
                </TabsContent>

                <TabsContent value="badges">
                  <Badges />
                </TabsContent>

                <TabsContent value="leaderboard">
                  <Leaderboard />
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
