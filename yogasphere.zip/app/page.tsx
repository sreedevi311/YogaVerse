"use client"

import { Suspense } from "react"
import { Navbar } from "@/components/navigation/navbar"
import { Footer } from "@/components/navigation/footer"
import { YogaScene } from "@/components/3d/yoga-scene"
import { HeroSection } from "@/components/home/hero-section"
import { FeaturesSection } from "@/components/home/features-section"
import { StatsSection } from "@/components/home/stats-section"

function LoadingFallback() {
  return (
    <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center">
      <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
    </div>
  )
}

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="pt-16">
        {/* Hero Section with 3D Background */}
        <div className="relative">
          <Suspense fallback={<LoadingFallback />}>
            <YogaScene />
          </Suspense>
          <HeroSection />
        </div>

        {/* Features Section */}
        <FeaturesSection />

        {/* Stats Section */}
        <StatsSection />
      </main>

      <Footer />
    </div>
  )
}
