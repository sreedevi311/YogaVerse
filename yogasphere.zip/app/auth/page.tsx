"use client"

import { useState, Suspense } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { AuthScene } from "@/components/3d/auth-scene"
import { AuthForm } from "@/components/auth/auth-form"
import { ArrowLeft } from "lucide-react"

function LoadingFallback() {
  return (
    <div className="absolute inset-0 bg-gradient-to-br from-primary to-accent flex items-center justify-center">
      <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-white"></div>
    </div>
  )
}

export default function AuthPage() {
  const [mode, setMode] = useState<"login" | "signup">("login")

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* 3D Background */}
      <Suspense fallback={<LoadingFallback />}>
        <AuthScene />
      </Suspense>

      {/* Back to Home */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6 }}
        className="absolute top-6 left-6 z-10"
      >
        <Link href="/" className="flex items-center space-x-2 text-white/80 hover:text-white transition-colors group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Home</span>
        </Link>
      </motion.div>

      {/* Auth Form */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-center mb-8"
          >
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-lg">Y</span>
              </div>
              <span className="font-serif font-bold text-2xl text-white">YogaSphere</span>
            </div>
          </motion.div>

          <AuthForm mode={mode} onToggleMode={() => setMode(mode === "login" ? "signup" : "login")} />
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-black/20 to-transparent pointer-events-none" />
    </div>
  )
}
