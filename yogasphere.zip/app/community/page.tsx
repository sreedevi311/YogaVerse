"use client"

import { Navbar } from "@/components/navigation/navbar"
import { Footer } from "@/components/navigation/footer"
import { ForumPosts } from "@/components/community/forum-posts"
import { EventsCalendar } from "@/components/community/events-calendar"
import { LiveChat } from "@/components/community/live-chat"
import { GlobalChallenges } from "@/components/community/global-challenges"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MessageCircle, Calendar, Users, Trophy, Settings, Bell } from "lucide-react"

export default function CommunityPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Navbar />

      <main className="pt-20 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-serif font-bold text-foreground mb-2">Community Hub</h1>
                <p className="text-muted-foreground">
                  Connect with fellow yogis, join events, and participate in global challenges
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <Users className="w-3 h-3" />
                  <span>2,847 online</span>
                </Badge>
                <Button variant="outline" size="sm">
                  <Bell className="w-4 h-4 mr-2" />
                  Notifications
                </Button>
                <Button variant="outline" size="sm">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </div>
            </div>
          </div>

          {/* Community Tabs */}
          <Tabs defaultValue="forum" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="forum" className="flex items-center space-x-2">
                <MessageCircle className="w-4 h-4" />
                <span>Forum</span>
              </TabsTrigger>
              <TabsTrigger value="events" className="flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <span>Events</span>
              </TabsTrigger>
              <TabsTrigger value="chat" className="flex items-center space-x-2">
                <Users className="w-4 h-4" />
                <span>Live Chat</span>
              </TabsTrigger>
              <TabsTrigger value="challenges" className="flex items-center space-x-2">
                <Trophy className="w-4 h-4" />
                <span>Challenges</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="forum">
              <ForumPosts />
            </TabsContent>

            <TabsContent value="events">
              <EventsCalendar />
            </TabsContent>

            <TabsContent value="chat">
              <LiveChat />
            </TabsContent>

            <TabsContent value="challenges">
              <GlobalChallenges />
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  )
}
