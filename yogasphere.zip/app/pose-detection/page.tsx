"use client"

import { useState } from "react"
import { Navbar } from "@/components/navigation/navbar"
import { Footer } from "@/components/navigation/footer"
import { WebcamFeed } from "@/components/pose-detection/webcam-feed"
import { HealthMetrics } from "@/components/pose-detection/health-metrics"
import { PoseTips } from "@/components/pose-detection/pose-tips"
import { AIFeedback } from "@/components/pose-detection/ai-feedback"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, Square, Settings } from "lucide-react"

export default function PoseDetectionPage() {
  const [isSessionActive, setIsSessionActive] = useState(false)
  const [isPaused, setIsPaused] = useState(false)

  const handleStartSession = () => {
    setIsSessionActive(true)
    setIsPaused(false)
  }

  const handlePauseSession = () => {
    setIsPaused(!isPaused)
  }

  const handleStopSession = () => {
    setIsSessionActive(false)
    setIsPaused(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Navbar />

      <main className="pt-20 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-serif font-bold text-foreground mb-2">AI Pose Detection</h1>
                <p className="text-muted-foreground">
                  Real-time yoga pose analysis with instant feedback and health monitoring
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <Badge variant={isSessionActive ? "default" : "secondary"}>
                  {isSessionActive ? (isPaused ? "Paused" : "Active") : "Inactive"}
                </Badge>
                <Button variant="outline" size="sm">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              </div>
            </div>
          </div>

          {/* Session Controls */}
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex items-center justify-center space-x-4">
                {!isSessionActive ? (
                  <Button onClick={handleStartSession} size="lg" className="gradient-primary text-white">
                    <Play className="w-5 h-5 mr-2" />
                    Start Session
                  </Button>
                ) : (
                  <>
                    <Button onClick={handlePauseSession} variant="outline" size="lg">
                      {isPaused ? <Play className="w-5 h-5 mr-2" /> : <Pause className="w-5 h-5 mr-2" />}
                      {isPaused ? "Resume" : "Pause"}
                    </Button>
                    <Button onClick={handleStopSession} variant="destructive" size="lg">
                      <Square className="w-5 h-5 mr-2" />
                      Stop Session
                    </Button>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Left Sidebar - Pose Tips */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold">Pose Guide</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <PoseTips />
                </CardContent>
              </Card>
            </div>

            {/* Center - Webcam Feed */}
            <div className="lg:col-span-2">
              <WebcamFeed onPoseDetected={(pose) => console.log("Pose detected:", pose)} />
            </div>

            {/* Right Sidebar - Health Metrics & AI Feedback */}
            <div className="lg:col-span-1 space-y-6">
              {/* Health Metrics */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold">Live Health Data</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <HealthMetrics />
                </CardContent>
              </Card>

              {/* AI Feedback */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg font-semibold">AI Analysis</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <AIFeedback />
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
