"use client"

import { useRef } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { Float, OrbitControls } from "@react-three/drei"
import type * as THREE from "three"

function FloatingLotus({ position }: { position: [number, number, number] }) {
  const groupRef = useRef<THREE.Group>(null)

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.3) * 0.1
    }
  })

  return (
    <group ref={groupRef} position={position}>
      <Float speed={1.5} rotationIntensity={0.3} floatIntensity={0.4}>
        {/* Lotus petals */}
        {Array.from({ length: 8 }).map((_, i) => (
          <mesh
            key={i}
            position={[Math.cos((i / 8) * Math.PI * 2) * 0.8, 0, Math.sin((i / 8) * Math.PI * 2) * 0.8]}
            rotation={[0, (i / 8) * Math.PI * 2, Math.PI / 6]}
          >
            <coneGeometry args={[0.3, 1.2, 8]} />
            <meshStandardMaterial color="#8b5cf6" transparent opacity={0.7} />
          </mesh>
        ))}
        {/* Center */}
        <mesh position={[0, 0.2, 0]}>
          <sphereGeometry args={[0.4]} />
          <meshStandardMaterial color="#6366f1" transparent opacity={0.8} />
        </mesh>
      </Float>
    </group>
  )
}

function MeditationOrb({ position, color }: { position: [number, number, number]; color: string }) {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = state.clock.elapsedTime * 0.2
      meshRef.current.rotation.y = state.clock.elapsedTime * 0.1
    }
  })

  return (
    <Float speed={2} rotationIntensity={0.2} floatIntensity={0.6}>
      <mesh ref={meshRef} position={position}>
        <icosahedronGeometry args={[0.8, 1]} />
        <meshStandardMaterial color={color} transparent opacity={0.6} wireframe />
      </mesh>
    </Float>
  )
}

export function AuthScene() {
  return (
    <div className="absolute inset-0 -z-10">
      <Canvas
        camera={{ position: [0, 0, 8], fov: 75 }}
        style={{ background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)" }}
      >
        <ambientLight intensity={0.4} />
        <directionalLight position={[10, 10, 5]} intensity={0.8} />
        <pointLight position={[-10, -10, -5]} intensity={0.6} color="#8b5cf6" />

        <FloatingLotus position={[-3, 1, -4]} />
        <FloatingLotus position={[4, -1, -5]} />

        <MeditationOrb position={[-5, 2, -3]} color="#6366f1" />
        <MeditationOrb position={[5, -2, -4]} color="#8b5cf6" />
        <MeditationOrb position={[2, 3, -2]} color="#a855f7" />

        <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.3} />
      </Canvas>
    </div>
  )
}
