"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Trophy, Medal, Award, Crown, TrendingUp, Users } from "lucide-react"

interface LeaderboardEntry {
  rank: number
  name: string
  avatar?: string
  level: number
  xp: number
  streak: number
  change: number
  country: string
}

const globalLeaderboard: LeaderboardEntry[] = [
  {
    rank: 1,
    name: "Sarah Chen",
    avatar: "/woman-doing-yoga.png",
    level: 28,
    xp: 15420,
    streak: 45,
    change: 0,
    country: "US",
  },
  {
    rank: 2,
    name: "Marcus Johnson",
    avatar: "/man-meditation.png",
    level: 26,
    xp: 14890,
    streak: 32,
    change: 1,
    country: "CA",
  },
  {
    rank: 3,
    name: "Priya Patel",
    avatar: "/woman-namaste.png",
    level: 25,
    xp: 14200,
    streak: 28,
    change: -1,
    country: "IN",
  },
  {
    rank: 4,
    name: "Alex Rivera",
    level: 24,
    xp: 13750,
    streak: 21,
    change: 2,
    country: "MX",
  },
  {
    rank: 5,
    name: "Emma Thompson",
    level: 23,
    xp: 13200,
    streak: 19,
    change: -1,
    country: "UK",
  },
]

const friendsLeaderboard: LeaderboardEntry[] = [
  {
    rank: 1,
    name: "You",
    level: 12,
    xp: 2450,
    streak: 7,
    change: 1,
    country: "US",
  },
  {
    rank: 2,
    name: "Jessica Wong",
    level: 11,
    xp: 2200,
    streak: 5,
    change: -1,
    country: "US",
  },
  {
    rank: 3,
    name: "David Kim",
    level: 10,
    xp: 1980,
    streak: 12,
    change: 0,
    country: "US",
  },
]

export function Leaderboard() {
  const [activeTab, setActiveTab] = useState("global")
  const [timeframe, setTimeframe] = useState("weekly")

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-5 h-5 text-yellow-500" />
      case 2:
        return <Medal className="w-5 h-5 text-gray-400" />
      case 3:
        return <Award className="w-5 h-5 text-amber-600" />
      default:
        return <span className="text-sm font-bold text-muted-foreground">#{rank}</span>
    }
  }

  const getChangeIndicator = (change: number) => {
    if (change > 0) {
      return <TrendingUp className="w-4 h-4 text-green-500" />
    } else if (change < 0) {
      return <TrendingUp className="w-4 h-4 text-red-500 rotate-180" />
    }
    return <div className="w-4 h-4" />
  }

  const currentLeaderboard = activeTab === "global" ? globalLeaderboard : friendsLeaderboard

  return (
    <div className="space-y-6">
      {/* Leaderboard Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Trophy className="w-6 h-6 text-yellow-500" />
              <span>Leaderboard</span>
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Button
                variant={timeframe === "weekly" ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeframe("weekly")}
              >
                Weekly
              </Button>
              <Button
                variant={timeframe === "monthly" ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeframe("monthly")}
              >
                Monthly
              </Button>
              <Button
                variant={timeframe === "alltime" ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeframe("alltime")}
              >
                All Time
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Leaderboard Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="global" className="flex items-center space-x-2">
            <Users className="w-4 h-4" />
            <span>Global</span>
          </TabsTrigger>
          <TabsTrigger value="friends" className="flex items-center space-x-2">
            <Users className="w-4 h-4" />
            <span>Friends</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab}>
          <Card>
            <CardContent className="p-0">
              <div className="space-y-0">
                {currentLeaderboard.map((entry, index) => (
                  <div
                    key={entry.rank}
                    className={`flex items-center justify-between p-4 border-b last:border-b-0 hover:bg-muted/50 transition-colors ${
                      entry.name === "You" ? "bg-primary/5 border-primary/20" : ""
                    }`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center justify-center w-8">{getRankIcon(entry.rank)}</div>

                      <Avatar className="w-10 h-10">
                        <AvatarImage src={entry.avatar || "/placeholder.svg"} />
                        <AvatarFallback>
                          {entry.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>

                      <div>
                        <div className="flex items-center space-x-2">
                          <span className={`font-medium ${entry.name === "You" ? "text-primary" : ""}`}>
                            {entry.name}
                          </span>
                          {entry.name === "You" && <Badge variant="secondary">You</Badge>}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Level {entry.level} • {entry.country}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4 text-right">
                      <div>
                        <div className="font-medium">{entry.xp.toLocaleString()} XP</div>
                        <div className="text-sm text-muted-foreground">{entry.streak} day streak</div>
                      </div>
                      <div className="flex items-center space-x-1">
                        {getChangeIndicator(entry.change)}
                        {entry.change !== 0 && (
                          <span className={`text-xs ${entry.change > 0 ? "text-green-500" : "text-red-500"}`}>
                            {Math.abs(entry.change)}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Your Rank Summary */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold mb-1">Your Current Rank</h3>
              <p className="text-muted-foreground">
                {activeTab === "global" ? "Global ranking among all users" : "Ranking among your friends"}
              </p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-primary">#{activeTab === "global" ? "23" : "1"}</div>
              <div className="text-sm text-muted-foreground">
                {activeTab === "global" ? "out of 50,000+" : "out of 3 friends"}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
