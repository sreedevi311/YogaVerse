"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Flame, Star, Target, Zap, Crown } from "lucide-react"

interface UserStats {
  level: number
  xp: number
  xpToNext: number
  streak: number
  totalSessions: number
  badges: number
  rank: number
}

export function UserProgress() {
  const [userStats, setUserStats] = useState<UserStats>({
    level: 12,
    xp: 2450,
    xpToNext: 3000,
    streak: 7,
    totalSessions: 89,
    badges: 15,
    rank: 23,
  })

  const [streakAnimation, setStreakAnimation] = useState(false)

  // Simulate streak updates
  useEffect(() => {
    const interval = setInterval(() => {
      setStreakAnimation(true)
      setTimeout(() => setStreakAnimation(false), 1000)
    }, 10000)

    return () => clearInterval(interval)
  }, [])

  const progressPercentage = (userStats.xp / userStats.xpToNext) * 100

  const getLevelTitle = (level: number) => {
    if (level >= 20) return "Yoga Master"
    if (level >= 15) return "Advanced Practitioner"
    if (level >= 10) return "Dedicated Student"
    if (level >= 5) return "Rising Yogi"
    return "Beginner"
  }

  return (
    <div className="space-y-6">
      {/* Level & XP Progress */}
      <Card className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-accent/10" />
        <CardContent className="relative p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                <Crown className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Level {userStats.level}</h2>
                <p className="text-muted-foreground">{getLevelTitle(userStats.level)}</p>
              </div>
            </div>
            <Badge variant="secondary" className="text-lg px-3 py-1">
              #{userStats.rank} Global
            </Badge>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Experience Points</span>
              <span>
                {userStats.xp.toLocaleString()} / {userStats.xpToNext.toLocaleString()} XP
              </span>
            </div>
            <Progress value={progressPercentage} className="h-3" />
            <p className="text-xs text-muted-foreground text-center">
              {(userStats.xpToNext - userStats.xp).toLocaleString()} XP to next level
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div
              className={`w-12 h-12 mx-auto mb-2 rounded-full bg-orange-100 flex items-center justify-center ${
                streakAnimation ? "animate-pulse" : ""
              }`}
            >
              <Flame className="w-6 h-6 text-orange-500" />
            </div>
            <div className="text-2xl font-bold">{userStats.streak}</div>
            <div className="text-xs text-muted-foreground">Day Streak</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-blue-100 flex items-center justify-center">
              <Target className="w-6 h-6 text-blue-500" />
            </div>
            <div className="text-2xl font-bold">{userStats.totalSessions}</div>
            <div className="text-xs text-muted-foreground">Total Sessions</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-yellow-100 flex items-center justify-center">
              <Star className="w-6 h-6 text-yellow-500" />
            </div>
            <div className="text-2xl font-bold">{userStats.badges}</div>
            <div className="text-xs text-muted-foreground">Badges Earned</div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-green-100 flex items-center justify-center">
              <Zap className="w-6 h-6 text-green-500" />
            </div>
            <div className="text-2xl font-bold">2,450</div>
            <div className="text-xs text-muted-foreground">Total XP</div>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Goals */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="w-5 h-5" />
            <span>Weekly Goals</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Practice Sessions</span>
              <span>4/5 completed</span>
            </div>
            <Progress value={80} className="h-2" />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Meditation Minutes</span>
              <span>45/60 minutes</span>
            </div>
            <Progress value={75} className="h-2" />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>New Poses Learned</span>
              <span>2/3 poses</span>
            </div>
            <Progress value={67} className="h-2" />
          </div>

          <Button className="w-full mt-4 bg-transparent" variant="outline">
            View All Goals
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
