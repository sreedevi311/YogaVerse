"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { motion, AnimatePresence } from "framer-motion"
import { Trophy, Star, Flame, Heart, Users, Award, Crown, Sparkles } from "lucide-react"

interface BadgeItem {
  id: string
  name: string
  description: string
  category: "achievement" | "milestone" | "special" | "social"
  rarity: "common" | "rare" | "epic" | "legendary"
  earned: boolean
  earnedDate?: string
  progress?: number
  total?: number
  icon: React.ComponentType<any>
  color: string
}

const badges: BadgeItem[] = [
  {
    id: "1",
    name: "First Steps",
    description: "Complete your first yoga session",
    category: "achievement",
    rarity: "common",
    earned: true,
    earnedDate: "2024-01-15",
    icon: Star,
    color: "text-yellow-500",
  },
  {
    id: "2",
    name: "Week Warrior",
    description: "Practice yoga for 7 consecutive days",
    category: "milestone",
    rarity: "rare",
    earned: true,
    earnedDate: "2024-01-22",
    icon: Flame,
    color: "text-orange-500",
  },
  {
    id: "3",
    name: "Pose Master",
    description: "Master 25 different yoga poses",
    category: "achievement",
    rarity: "epic",
    earned: false,
    progress: 18,
    total: 25,
    icon: Trophy,
    color: "text-purple-500",
  },
  {
    id: "4",
    name: "Community Leader",
    description: "Help 10 fellow yogis in the community",
    category: "social",
    rarity: "rare",
    earned: false,
    progress: 6,
    total: 10,
    icon: Users,
    color: "text-blue-500",
  },
  {
    id: "5",
    name: "Zen Master",
    description: "Complete 100 meditation sessions",
    category: "milestone",
    rarity: "legendary",
    earned: false,
    progress: 67,
    total: 100,
    icon: Crown,
    color: "text-indigo-500",
  },
  {
    id: "6",
    name: "Heart Healthy",
    description: "Maintain optimal heart rate for 30 sessions",
    category: "achievement",
    rarity: "epic",
    earned: true,
    earnedDate: "2024-02-01",
    icon: Heart,
    color: "text-red-500",
  },
]

export function Badges() {
  const [selectedBadge, setSelectedBadge] = useState<BadgeItem | null>(null)
  const [filter, setFilter] = useState<"all" | "earned" | "progress">("all")

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common":
        return "bg-gray-100 text-gray-800 border-gray-300"
      case "rare":
        return "bg-blue-100 text-blue-800 border-blue-300"
      case "epic":
        return "bg-purple-100 text-purple-800 border-purple-300"
      case "legendary":
        return "bg-yellow-100 text-yellow-800 border-yellow-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  const filteredBadges = badges.filter((badge) => {
    if (filter === "earned") return badge.earned
    if (filter === "progress") return !badge.earned
    return true
  })

  const earnedCount = badges.filter((b) => b.earned).length
  const totalCount = badges.length

  return (
    <div className="space-y-6">
      {/* Badge Overview */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-2">Badge Collection</h2>
              <p className="text-muted-foreground">
                {earnedCount} of {totalCount} badges earned
              </p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-2">
                <Award className="w-10 h-10 text-white" />
              </div>
              <div className="text-sm font-medium">{Math.round((earnedCount / totalCount) * 100)}% Complete</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Filter Tabs */}
      <Tabs value={filter} onValueChange={(value) => setFilter(value as any)}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="all">All Badges</TabsTrigger>
          <TabsTrigger value="earned">Earned ({earnedCount})</TabsTrigger>
          <TabsTrigger value="progress">In Progress</TabsTrigger>
        </TabsList>

        <TabsContent value={filter}>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredBadges.map((badge) => (
              <motion.div
                key={badge.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedBadge(badge)}
              >
                <Card
                  className={`cursor-pointer transition-all duration-300 ${
                    badge.earned
                      ? "bg-gradient-to-br from-white to-gray-50 shadow-md"
                      : "bg-gray-50 opacity-60 hover:opacity-80"
                  }`}
                >
                  <CardContent className="p-4 text-center">
                    <div
                      className={`w-16 h-16 mx-auto mb-3 rounded-full flex items-center justify-center ${
                        badge.earned ? "bg-gradient-to-br from-primary/20 to-accent/20" : "bg-gray-200"
                      }`}
                    >
                      <badge.icon className={`w-8 h-8 ${badge.earned ? badge.color : "text-gray-400"}`} />
                    </div>

                    <h3 className="font-semibold text-sm mb-1">{badge.name}</h3>
                    <p className="text-xs text-muted-foreground mb-2 line-clamp-2">{badge.description}</p>

                    <div className="space-y-2">
                      <Badge className={`${getRarityColor(badge.rarity)} text-xs`} variant="outline">
                        {badge.rarity}
                      </Badge>

                      {badge.earned ? (
                        <div className="text-xs text-green-600 font-medium">
                          Earned {new Date(badge.earnedDate!).toLocaleDateString()}
                        </div>
                      ) : badge.progress !== undefined ? (
                        <div className="space-y-1">
                          <div className="text-xs text-muted-foreground">
                            {badge.progress} / {badge.total}
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-1">
                            <div
                              className="bg-primary h-1 rounded-full transition-all duration-300"
                              style={{ width: `${(badge.progress! / badge.total!) * 100}%` }}
                            />
                          </div>
                        </div>
                      ) : (
                        <div className="text-xs text-muted-foreground">Not started</div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Badge Detail Modal */}
      <AnimatePresence>
        {selectedBadge && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setSelectedBadge(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-lg p-6 max-w-md w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="text-center">
                <div
                  className={`w-24 h-24 mx-auto mb-4 rounded-full flex items-center justify-center ${
                    selectedBadge.earned ? "bg-gradient-to-br from-primary/20 to-accent/20" : "bg-gray-200"
                  }`}
                >
                  <selectedBadge.icon
                    className={`w-12 h-12 ${selectedBadge.earned ? selectedBadge.color : "text-gray-400"}`}
                  />
                </div>

                <h2 className="text-xl font-bold mb-2">{selectedBadge.name}</h2>
                <p className="text-muted-foreground mb-4">{selectedBadge.description}</p>

                <div className="space-y-3">
                  <Badge className={`${getRarityColor(selectedBadge.rarity)}`} variant="outline">
                    {selectedBadge.rarity} badge
                  </Badge>

                  {selectedBadge.earned ? (
                    <div className="text-green-600 font-medium">
                      <Sparkles className="w-4 h-4 inline mr-1" />
                      Earned on {new Date(selectedBadge.earnedDate!).toLocaleDateString()}
                    </div>
                  ) : selectedBadge.progress !== undefined ? (
                    <div className="space-y-2">
                      <div className="text-sm">
                        Progress: {selectedBadge.progress} / {selectedBadge.total}
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full"
                          style={{ width: `${(selectedBadge.progress! / selectedBadge.total!) * 100}%` }}
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="text-muted-foreground">Ready to start!</div>
                  )}
                </div>

                <Button className="w-full mt-6" onClick={() => setSelectedBadge(null)}>
                  Close
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
