"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Clock, Users, Trophy, Star, Target, Calendar, Flame } from "lucide-react"

interface Challenge {
  id: string
  title: string
  description: string
  type: "daily" | "weekly" | "monthly" | "special"
  difficulty: "easy" | "medium" | "hard"
  reward: number
  progress: number
  total: number
  timeLeft: string
  participants?: number
  icon: React.ComponentType<any>
  color: string
}

const challenges: Challenge[] = [
  {
    id: "1",
    title: "Morning Warrior",
    description: "Complete 5 morning yoga sessions this week",
    type: "weekly",
    difficulty: "medium",
    reward: 250,
    progress: 3,
    total: 5,
    timeLeft: "3 days",
    icon: Target,
    color: "text-blue-500",
  },
  {
    id: "2",
    title: "Streak Master",
    description: "Maintain a 7-day practice streak",
    type: "special",
    difficulty: "hard",
    reward: 500,
    progress: 7,
    total: 7,
    timeLeft: "Completed!",
    icon: Flame,
    color: "text-orange-500",
  },
  {
    id: "3",
    title: "Community Spirit",
    description: "Join 3 group sessions this month",
    type: "monthly",
    difficulty: "easy",
    reward: 150,
    progress: 1,
    total: 3,
    timeLeft: "18 days",
    participants: 1247,
    icon: Users,
    color: "text-green-500",
  },
  {
    id: "4",
    title: "Perfect Balance",
    description: "Hold tree pose for 60 seconds",
    type: "daily",
    difficulty: "medium",
    reward: 100,
    progress: 45,
    total: 60,
    timeLeft: "12 hours",
    icon: Star,
    color: "text-purple-500",
  },
]

export function Challenges() {
  const [activeTab, setActiveTab] = useState("active")

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-100 text-green-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "hard":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "daily":
        return "bg-blue-100 text-blue-800"
      case "weekly":
        return "bg-purple-100 text-purple-800"
      case "monthly":
        return "bg-indigo-100 text-indigo-800"
      case "special":
        return "bg-orange-100 text-orange-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const activeChallenges = challenges.filter((c) => c.progress < c.total)
  const completedChallenges = challenges.filter((c) => c.progress >= c.total)

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="active">Active Challenges</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-4">
          {activeChallenges.map((challenge) => (
            <Card key={challenge.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center`}>
                      <challenge.icon className={`w-6 h-6 ${challenge.color}`} />
                    </div>
                    <div>
                      <h3 className="font-semibold">{challenge.title}</h3>
                      <p className="text-sm text-muted-foreground">{challenge.description}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-2 mb-1">
                      <Trophy className="w-4 h-4 text-yellow-500" />
                      <span className="font-medium">{challenge.reward} XP</span>
                    </div>
                    <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      <span>{challenge.timeLeft}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Badge className={getDifficultyColor(challenge.difficulty)} variant="secondary">
                      {challenge.difficulty}
                    </Badge>
                    <Badge className={getTypeColor(challenge.type)} variant="secondary">
                      {challenge.type}
                    </Badge>
                    {challenge.participants && (
                      <Badge variant="outline">
                        <Users className="w-3 h-3 mr-1" />
                        {challenge.participants.toLocaleString()} joined
                      </Badge>
                    )}
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>
                        {challenge.progress} / {challenge.total}
                      </span>
                    </div>
                    <Progress value={(challenge.progress / challenge.total) * 100} className="h-2" />
                  </div>

                  <Button className="w-full bg-transparent" variant="outline">
                    Continue Challenge
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="completed" className="space-y-4">
          {completedChallenges.map((challenge) => (
            <Card key={challenge.id} className="opacity-75">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                      <Trophy className="w-6 h-6 text-green-500" />
                    </div>
                    <div>
                      <h3 className="font-semibold">{challenge.title}</h3>
                      <p className="text-sm text-muted-foreground">{challenge.description}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="default" className="bg-green-500">
                      Completed
                    </Badge>
                    <div className="text-sm text-muted-foreground mt-1">+{challenge.reward} XP earned</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>

      {/* Challenge Categories */}
      <Card>
        <CardHeader>
          <CardTitle>Explore More Challenges</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-20 flex-col bg-transparent">
              <Calendar className="w-6 h-6 mb-2" />
              <span className="text-xs">Daily</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col bg-transparent">
              <Target className="w-6 h-6 mb-2" />
              <span className="text-xs">Weekly</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col bg-transparent">
              <Users className="w-6 h-6 mb-2" />
              <span className="text-xs">Community</span>
            </Button>
            <Button variant="outline" className="h-20 flex-col bg-transparent">
              <Star className="w-6 h-6 mb-2" />
              <span className="text-xs">Special</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
