"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Brain, Activity, Trophy, Users, BarChart3, Shield } from "lucide-react"

const features = [
  {
    icon: Brain,
    title: "AI Pose Detection",
    description: "Real-time yoga pose analysis with instant feedback and corrections using advanced computer vision.",
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    icon: Activity,
    title: "Personalized Programs",
    description: "Customized yoga routines based on your health conditions, fitness level, and wellness goals.",
    gradient: "from-purple-500 to-pink-500",
  },
  {
    icon: BarChart3,
    title: "Health Analytics",
    description:
      "Comprehensive tracking of breathing patterns, stress levels, and progress with Google Fit integration.",
    gradient: "from-green-500 to-emerald-500",
  },
  {
    icon: Trophy,
    title: "Gamification",
    description: "Stay motivated with streaks, challenges, badges, and community leaderboards.",
    gradient: "from-orange-500 to-red-500",
  },
  {
    icon: Users,
    title: "Community Hub",
    description: "Connect with fellow practitioners, join live sessions, and participate in global challenges.",
    gradient: "from-indigo-500 to-purple-500",
  },
  {
    icon: Shield,
    title: "Cultural Authenticity",
    description: "Learn the true essence of yoga with educational content preserving ancient wisdom.",
    gradient: "from-teal-500 to-blue-500",
  },
]

export function FeaturesSection() {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-serif font-bold text-foreground mb-4">
            Everything You Need for{" "}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Mindful Living
            </span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover powerful features designed to enhance your yoga practice and overall wellness journey.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full hover-3d border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6 text-center space-y-4">
                  <div
                    className={`w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center`}
                  >
                    <feature.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
