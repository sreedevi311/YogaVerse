"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, CheckCircle, AlertCircle } from "lucide-react"

const poseTips = [
  {
    name: "Mountain Pose",
    difficulty: "Beginner",
    duration: "30s - 1min",
    benefits: ["Improves posture", "Increases awareness", "Strengthens legs"],
    instructions: [
      "Stand with feet hip-width apart",
      "Distribute weight evenly on both feet",
      "Engage your thighs and lift kneecaps",
      "Lengthen your spine and relax shoulders",
      "Breathe deeply and hold the pose",
    ],
    common_mistakes: ["Locking knees too tightly", "Tilting pelvis forward or back", "Tensing shoulders"],
  },
  {
    name: "Warrior I",
    difficulty: "Intermediate",
    duration: "30s - 1min each side",
    benefits: ["Strengthens legs", "Opens hips", "Improves balance"],
    instructions: [
      "Step left foot back 3-4 feet",
      "Turn left foot out 45 degrees",
      "Bend right knee over ankle",
      "Square hips toward front",
      "Raise arms overhead",
    ],
    common_mistakes: ["Front knee extending past ankle", "Back foot not grounded", "Hips not squared"],
  },
  {
    name: "Downward Dog",
    difficulty: "Beginner",
    duration: "30s - 2min",
    benefits: ["Stretches hamstrings", "Strengthens arms", "Energizes body"],
    instructions: [
      "Start on hands and knees",
      "Tuck toes under and lift hips up",
      "Straighten legs as much as possible",
      "Press hands firmly into mat",
      "Create inverted V shape",
    ],
    common_mistakes: ["Hands too close together", "Weight in hands instead of legs", "Rounded shoulders"],
  },
]

export function PoseTips() {
  const [currentPoseIndex, setCurrentPoseIndex] = useState(0)
  const currentPose = poseTips[currentPoseIndex]

  const nextPose = () => {
    setCurrentPoseIndex((prev) => (prev + 1) % poseTips.length)
  }

  const prevPose = () => {
    setCurrentPoseIndex((prev) => (prev - 1 + poseTips.length) % poseTips.length)
  }

  return (
    <div className="space-y-4">
      {/* Pose Navigation */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold">{currentPose.name}</CardTitle>
            <div className="flex space-x-1">
              <Button variant="outline" size="sm" onClick={prevPose}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={nextPose}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant={currentPose.difficulty === "Beginner" ? "secondary" : "default"}>
              {currentPose.difficulty}
            </Badge>
            <span className="text-sm text-muted-foreground">{currentPose.duration}</span>
          </div>
        </CardHeader>
      </Card>

      {/* Benefits */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Benefits</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <ul className="space-y-1">
            {currentPose.benefits.map((benefit, index) => (
              <li key={index} className="flex items-center space-x-2 text-sm">
                <CheckCircle className="w-3 h-3 text-green-500" />
                <span>{benefit}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Step-by-Step</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <ol className="space-y-2">
            {currentPose.instructions.map((instruction, index) => (
              <li key={index} className="flex space-x-3 text-sm">
                <span className="flex-shrink-0 w-5 h-5 bg-primary text-white rounded-full flex items-center justify-center text-xs">
                  {index + 1}
                </span>
                <span>{instruction}</span>
              </li>
            ))}
          </ol>
        </CardContent>
      </Card>

      {/* Common Mistakes */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Avoid These Mistakes</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <ul className="space-y-1">
            {currentPose.common_mistakes.map((mistake, index) => (
              <li key={index} className="flex items-center space-x-2 text-sm">
                <AlertCircle className="w-3 h-3 text-yellow-500" />
                <span>{mistake}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
