"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Camera, CameraOff, RotateCcw } from "lucide-react"

interface WebcamFeedProps {
  onPoseDetected?: (pose: any) => void
}

export function WebcamFeed({ onPoseDetected }: WebcamFeedProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isActive, setIsActive] = useState(false)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [currentPose, setCurrentPose] = useState<string>("Mountain Pose")

  // Mock pose detection keypoints
  const mockKeypoints = [
    { x: 320, y: 100, confidence: 0.9, name: "nose" },
    { x: 300, y: 150, confidence: 0.8, name: "left_shoulder" },
    { x: 340, y: 150, confidence: 0.8, name: "right_shoulder" },
    { x: 280, y: 200, confidence: 0.7, name: "left_elbow" },
    { x: 360, y: 200, confidence: 0.7, name: "right_elbow" },
    { x: 260, y: 250, confidence: 0.6, name: "left_wrist" },
    { x: 380, y: 250, confidence: 0.6, name: "right_wrist" },
    { x: 300, y: 300, confidence: 0.8, name: "left_hip" },
    { x: 340, y: 300, confidence: 0.8, name: "right_hip" },
    { x: 290, y: 400, confidence: 0.7, name: "left_knee" },
    { x: 350, y: 400, confidence: 0.7, name: "right_knee" },
    { x: 285, y: 500, confidence: 0.6, name: "left_ankle" },
    { x: 355, y: 500, confidence: 0.6, name: "right_ankle" },
  ]

  const startWebcam = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480 },
        audio: false,
      })

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
        setStream(mediaStream)
        setIsActive(true)
      }
    } catch (error) {
      console.error("Error accessing webcam:", error)
    }
  }

  const stopWebcam = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
      setIsActive(false)
    }
  }

  const drawPoseOverlay = () => {
    const canvas = canvasRef.current
    const video = videoRef.current

    if (!canvas || !video) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw pose keypoints
    mockKeypoints.forEach((point, index) => {
      if (point.confidence > 0.5) {
        ctx.beginPath()
        ctx.arc(point.x, point.y, 6, 0, 2 * Math.PI)
        ctx.fillStyle = `hsl(${240 + index * 20}, 70%, 60%)`
        ctx.fill()

        // Draw confidence text
        ctx.fillStyle = "white"
        ctx.font = "12px Arial"
        ctx.fillText(`${(point.confidence * 100).toFixed(0)}%`, point.x + 10, point.y - 10)
      }
    })

    // Draw skeleton connections
    const connections = [
      [0, 1],
      [0, 2],
      [1, 3],
      [2, 4],
      [3, 5],
      [4, 6], // Upper body
      [1, 7],
      [2, 8],
      [7, 8],
      [7, 9],
      [8, 10],
      [9, 11],
      [10, 12], // Lower body
    ]

    ctx.strokeStyle = "#6366f1"
    ctx.lineWidth = 2
    connections.forEach(([start, end]) => {
      const startPoint = mockKeypoints[start]
      const endPoint = mockKeypoints[end]

      if (startPoint.confidence > 0.5 && endPoint.confidence > 0.5) {
        ctx.beginPath()
        ctx.moveTo(startPoint.x, startPoint.y)
        ctx.lineTo(endPoint.x, endPoint.y)
        ctx.stroke()
      }
    })
  }

  useEffect(() => {
    if (isActive) {
      const interval = setInterval(() => {
        drawPoseOverlay()
        // Mock pose detection callback
        onPoseDetected?.({
          pose: currentPose,
          confidence: 0.85,
          keypoints: mockKeypoints,
        })
      }, 100)

      return () => clearInterval(interval)
    }
  }, [isActive, currentPose, onPoseDetected])

  return (
    <Card className="w-full">
      <CardContent className="p-6">
        <div className="relative bg-gray-900 rounded-lg overflow-hidden">
          {/* Video Feed */}
          <video ref={videoRef} autoPlay playsInline muted className="w-full h-auto" style={{ maxHeight: "480px" }} />

          {/* Pose Overlay Canvas */}
          <canvas ref={canvasRef} width={640} height={480} className="absolute inset-0 w-full h-full" />

          {/* Controls Overlay */}
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {!isActive ? (
              <Button onClick={startWebcam} className="bg-primary hover:bg-primary/90">
                <Camera className="w-4 h-4 mr-2" />
                Start Camera
              </Button>
            ) : (
              <>
                <Button onClick={stopWebcam} variant="destructive">
                  <CameraOff className="w-4 h-4 mr-2" />
                  Stop Camera
                </Button>
                <Button
                  onClick={() => setCurrentPose(currentPose === "Mountain Pose" ? "Warrior I" : "Mountain Pose")}
                  variant="outline"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Switch Pose
                </Button>
              </>
            )}
          </div>

          {/* Pose Detection Status */}
          {isActive && (
            <div className="absolute top-4 left-4 bg-black/70 text-white px-3 py-2 rounded-lg">
              <div className="text-sm font-medium">Detected: {currentPose}</div>
              <div className="text-xs text-green-400">Confidence: 85%</div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
