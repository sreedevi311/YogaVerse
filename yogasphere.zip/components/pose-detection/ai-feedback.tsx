"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { CheckCircle, AlertTriangle, TrendingUp, Target } from "lucide-react"

interface FeedbackItem {
  type: "success" | "warning" | "improvement"
  message: string
  score?: number
}

export function AIFeedback() {
  const [feedback, setFeedback] = useState<FeedbackItem[]>([
    { type: "success", message: "Great alignment in your spine!" },
    { type: "warning", message: "Try to distribute weight evenly on both feet" },
    { type: "improvement", message: "Engage your core muscles more", score: 75 },
  ])

  const [overallScore, setOverallScore] = useState(82)
  const [sessionTime, setSessionTime] = useState(0)

  useEffect(() => {
    // Simulate real-time feedback updates
    const feedbackInterval = setInterval(() => {
      const newFeedback = [
        { type: "success" as const, message: "Excellent breathing rhythm!" },
        { type: "success" as const, message: "Perfect shoulder alignment!" },
        { type: "warning" as const, message: "Slightly bend your front knee more" },
        {
          type: "improvement" as const,
          message: "Focus on lengthening your spine",
          score: Math.floor(Math.random() * 30) + 70,
        },
        {
          type: "improvement" as const,
          message: "Deepen your hip flexor stretch",
          score: Math.floor(Math.random() * 25) + 75,
        },
      ]

      setFeedback([newFeedback[Math.floor(Math.random() * newFeedback.length)]])
      setOverallScore((prev) => Math.max(60, Math.min(100, prev + (Math.random() - 0.5) * 10)))
    }, 3000)

    // Session timer
    const timerInterval = setInterval(() => {
      setSessionTime((prev) => prev + 1)
    }, 1000)

    return () => {
      clearInterval(feedbackInterval)
      clearInterval(timerInterval)
    }
  }, [])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-500"
    if (score >= 75) return "text-blue-500"
    if (score >= 60) return "text-yellow-500"
    return "text-red-500"
  }

  const getScoreLabel = (score: number) => {
    if (score >= 90) return "Excellent"
    if (score >= 75) return "Good"
    if (score >= 60) return "Fair"
    return "Needs Work"
  }

  return (
    <div className="space-y-4">
      {/* Session Overview */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Session Overview</CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-muted-foreground">Duration</span>
            <span className="font-medium">{formatTime(sessionTime)}</span>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Overall Score</span>
              <span className={`font-bold ${getScoreColor(overallScore)}`}>{Math.round(overallScore)}%</span>
            </div>
            <Progress value={overallScore} className="h-2" />
            <div className="text-center">
              <Badge variant={overallScore >= 75 ? "default" : "secondary"}>{getScoreLabel(overallScore)}</Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Real-time Feedback */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">AI Feedback</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-3">
            {feedback.map((item, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 rounded-lg bg-muted/50">
                {item.type === "success" && <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />}
                {item.type === "warning" && <AlertTriangle className="w-4 h-4 text-yellow-500 mt-0.5" />}
                {item.type === "improvement" && <TrendingUp className="w-4 h-4 text-blue-500 mt-0.5" />}

                <div className="flex-1 space-y-1">
                  <p className="text-sm">{item.message}</p>
                  {item.score && (
                    <div className="flex items-center space-x-2">
                      <Progress value={item.score} className="h-1 flex-1" />
                      <span className="text-xs text-muted-foreground">{item.score}%</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Goals */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium flex items-center space-x-2">
            <Target className="w-4 h-4" />
            <span>Today's Goals</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm">Practice Time</span>
              <div className="flex items-center space-x-2">
                <Progress value={(sessionTime / 1200) * 100} className="w-16 h-2" />
                <span className="text-xs text-muted-foreground">{formatTime(sessionTime)}/20:00</span>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm">Poses Mastered</span>
              <div className="flex items-center space-x-2">
                <Progress value={66} className="w-16 h-2" />
                <span className="text-xs text-muted-foreground">2/3</span>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm">Accuracy Target</span>
              <div className="flex items-center space-x-2">
                <Progress value={overallScore} className="w-16 h-2" />
                <span className="text-xs text-muted-foreground">{Math.round(overallScore)}/85%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
