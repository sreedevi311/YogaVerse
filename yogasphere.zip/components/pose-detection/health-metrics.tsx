"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Heart, Activity, Zap, Wifi } from "lucide-react"

interface HealthMetric {
  label: string
  value: number
  unit: string
  icon: React.ComponentType<any>
  color: string
  target?: number
}

export function HealthMetrics() {
  const [metrics, setMetrics] = useState<HealthMetric[]>([
    { label: "Heart Rate", value: 72, unit: "bpm", icon: Heart, color: "text-red-500", target: 80 },
    { label: "Breath Rate", value: 16, unit: "/min", icon: Activity, color: "text-blue-500", target: 20 },
    { label: "Stress Level", value: 35, unit: "%", icon: Zap, color: "text-yellow-500", target: 100 },
  ])

  const [isConnected, setIsConnected] = useState(true)

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics((prev) =>
        prev.map((metric) => ({
          ...metric,
          value: Math.max(0, metric.value + (Math.random() - 0.5) * 4),
        })),
      )
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-4">
      {/* Connection Status */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-2">
            <Wifi className={`w-4 h-4 ${isConnected ? "text-green-500" : "text-red-500"}`} />
            <span className="text-sm font-medium">{isConnected ? "Google Fit Connected" : "Disconnected"}</span>
            <div className={`w-2 h-2 rounded-full ${isConnected ? "bg-green-500" : "bg-red-500"} animate-pulse`} />
          </div>
        </CardContent>
      </Card>

      {/* Live Metrics */}
      {metrics.map((metric) => (
        <Card key={metric.label}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center space-x-2">
              <metric.icon className={`w-4 h-4 ${metric.color}`} />
              <span>{metric.label}</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-2">
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl font-bold">{Math.round(metric.value)}</span>
                <span className="text-sm text-muted-foreground">{metric.unit}</span>
              </div>

              {metric.target && (
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Current</span>
                    <span>
                      Target: {metric.target}
                      {metric.unit}
                    </span>
                  </div>
                  <Progress value={(metric.value / metric.target) * 100} className="h-2" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}

      {/* Breathing Guide */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Breathing Guide</CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-full border-4 border-primary animate-pulse flex items-center justify-center">
              <span className="text-xs font-medium">Breathe</span>
            </div>
            <div className="text-sm text-muted-foreground">
              <div>Inhale: 4s</div>
              <div>Hold: 4s</div>
              <div>Exhale: 6s</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
