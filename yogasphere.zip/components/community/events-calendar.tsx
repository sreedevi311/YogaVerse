"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Calendar, Clock, MapPin, Users, Video, Star } from "lucide-react"

interface Event {
  id: string
  title: string
  description: string
  instructor: {
    name: string
    avatar?: string
    rating: number
  }
  date: string
  time: string
  duration: number
  type: "live" | "workshop" | "challenge" | "retreat"
  location: "online" | "studio" | string
  participants: number
  maxParticipants?: number
  level: "beginner" | "intermediate" | "advanced" | "all"
  price: number
  tags: string[]
}

const events: Event[] = [
  {
    id: "1",
    title: "Morning Flow & Meditation",
    description: "Start your day with energizing vinyasa flow followed by guided meditation",
    instructor: {
      name: "Sarah Chen",
      avatar: "/woman-doing-yoga.png",
      rating: 4.9,
    },
    date: "2025-01-12",
    time: "07:00 AM",
    duration: 60,
    type: "live",
    location: "online",
    participants: 45,
    maxParticipants: 50,
    level: "all",
    price: 0,
    tags: ["vinyasa", "meditation", "morning"],
  },
  {
    id: "2",
    title: "Advanced Arm Balances Workshop",
    description: "Master challenging arm balances with proper alignment and progressions",
    instructor: {
      name: "Marcus Johnson",
      avatar: "/man-meditation.png",
      rating: 4.8,
    },
    date: "2025-01-13",
    time: "02:00 PM",
    duration: 90,
    type: "workshop",
    location: "online",
    participants: 23,
    maxParticipants: 30,
    level: "advanced",
    price: 25,
    tags: ["arm-balances", "strength", "advanced"],
  },
  {
    id: "3",
    title: "Yoga for Stress Relief",
    description: "Gentle restorative practice to release tension and calm the mind",
    instructor: {
      name: "Priya Patel",
      avatar: "/woman-namaste.png",
      rating: 4.9,
    },
    date: "2025-01-14",
    time: "06:00 PM",
    duration: 45,
    type: "live",
    location: "online",
    participants: 67,
    maxParticipants: 100,
    level: "beginner",
    price: 0,
    tags: ["restorative", "stress-relief", "relaxation"],
  },
]

export function EventsCalendar() {
  const [selectedType, setSelectedType] = useState<string>("all")

  const eventTypes = [
    { value: "all", label: "All Events" },
    { value: "live", label: "Live Classes" },
    { value: "workshop", label: "Workshops" },
    { value: "challenge", label: "Challenges" },
    { value: "retreat", label: "Retreats" },
  ]

  const getTypeColor = (type: string) => {
    switch (type) {
      case "live":
        return "bg-red-100 text-red-800"
      case "workshop":
        return "bg-blue-100 text-blue-800"
      case "challenge":
        return "bg-green-100 text-green-800"
      case "retreat":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getLevelColor = (level: string) => {
    switch (level) {
      case "beginner":
        return "bg-green-100 text-green-800"
      case "intermediate":
        return "bg-yellow-100 text-yellow-800"
      case "advanced":
        return "bg-red-100 text-red-800"
      case "all":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const filteredEvents = selectedType === "all" ? events : events.filter((event) => event.type === selectedType)

  return (
    <div className="space-y-6">
      {/* Event Type Filter */}
      <div className="flex flex-wrap gap-2">
        {eventTypes.map((type) => (
          <Button
            key={type.value}
            variant={selectedType === type.value ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedType(type.value)}
          >
            {type.label}
          </Button>
        ))}
      </div>

      {/* Upcoming Events */}
      <div className="space-y-4">
        {filteredEvents.map((event) => (
          <Card key={event.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <h3 className="font-semibold text-lg">{event.title}</h3>
                    <Badge className={getTypeColor(event.type)} variant="secondary">
                      {event.type}
                    </Badge>
                    {event.price === 0 && (
                      <Badge variant="outline" className="text-green-600 border-green-600">
                        Free
                      </Badge>
                    )}
                  </div>
                  <p className="text-muted-foreground mb-3">{event.description}</p>

                  <div className="flex flex-wrap gap-1 mb-3">
                    {event.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        #{tag}
                      </Badge>
                    ))}
                  </div>
                </div>

                {event.price > 0 && (
                  <div className="text-right">
                    <div className="text-2xl font-bold text-primary">${event.price}</div>
                    <div className="text-xs text-muted-foreground">per person</div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span>
                      {new Date(event.date).toLocaleDateString("en-US", {
                        weekday: "long",
                        month: "long",
                        day: "numeric",
                      })}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span>
                      {event.time} ({event.duration} min)
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    {event.location === "online" ? (
                      <Video className="w-4 h-4 text-muted-foreground" />
                    ) : (
                      <MapPin className="w-4 h-4 text-muted-foreground" />
                    )}
                    <span className="capitalize">{event.location}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Avatar className="w-6 h-6">
                      <AvatarImage src={event.instructor.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="text-xs">
                        {event.instructor.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium">{event.instructor.name}</span>
                    <div className="flex items-center space-x-1">
                      <Star className="w-3 h-3 text-yellow-500 fill-current" />
                      <span className="text-xs">{event.instructor.rating}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span>
                      {event.participants}
                      {event.maxParticipants && `/${event.maxParticipants}`} participants
                    </span>
                  </div>
                  <Badge className={getLevelColor(event.level)} variant="secondary">
                    {event.level}
                  </Badge>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  {event.maxParticipants && event.participants >= event.maxParticipants ? (
                    <span className="text-red-600 font-medium">Event Full</span>
                  ) : (
                    <span>{event.maxParticipants && `${event.maxParticipants - event.participants} spots left`}</span>
                  )}
                </div>
                <div className="space-x-2">
                  <Button variant="outline" size="sm">
                    Learn More
                  </Button>
                  <Button
                    size="sm"
                    disabled={event.maxParticipants ? event.participants >= event.maxParticipants : false}
                  >
                    {event.price === 0 ? "Join Free" : "Register"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
