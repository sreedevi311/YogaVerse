"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import { Heart, MessageCircle, Share2, MoreHorizontal, Pin, Flame } from "lucide-react"

interface ForumPost {
  id: string
  author: {
    name: string
    avatar?: string
    level: number
    badge?: string
  }
  title: string
  content: string
  category: string
  timestamp: string
  likes: number
  replies: number
  isPinned?: boolean
  isHot?: boolean
  tags: string[]
}

const forumPosts: ForumPost[] = [
  {
    id: "1",
    author: {
      name: "Sarah Chen",
      avatar: "/woman-doing-yoga.png",
      level: 28,
      badge: "Yoga Master",
    },
    title: "Tips for maintaining balance in Tree Pose",
    content:
      "I've been practicing yoga for 5 years and wanted to share some insights on improving balance in Vrksasana (Tree Pose). Focus on your drishti (gaze point) and engage your core...",
    category: "Tips & Techniques",
    timestamp: "2 hours ago",
    likes: 24,
    replies: 8,
    isPinned: true,
    tags: ["balance", "tree-pose", "beginner-friendly"],
  },
  {
    id: "2",
    author: {
      name: "Marcus Johnson",
      avatar: "/man-meditation.png",
      level: 26,
      badge: "Meditation Guide",
    },
    title: "30-Day Meditation Challenge - Join me!",
    content:
      "Starting a 30-day meditation challenge tomorrow. Who wants to join? We can share our experiences and support each other through this journey...",
    category: "Challenges",
    timestamp: "4 hours ago",
    likes: 45,
    replies: 23,
    isHot: true,
    tags: ["meditation", "challenge", "community"],
  },
  {
    id: "3",
    author: {
      name: "Priya Patel",
      avatar: "/woman-namaste.png",
      level: 25,
      badge: "Wellness Coach",
    },
    title: "How yoga helped me through anxiety",
    content:
      "I wanted to share my personal story about how yoga became my anchor during difficult times. The breathing techniques and mindful movement...",
    category: "Personal Stories",
    timestamp: "6 hours ago",
    likes: 67,
    replies: 15,
    tags: ["mental-health", "anxiety", "personal-story"],
  },
]

export function ForumPosts() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [newPost, setNewPost] = useState("")
  const [showNewPost, setShowNewPost] = useState(false)

  const categories = ["All", "Tips & Techniques", "Challenges", "Personal Stories", "Q&A", "Equipment"]

  const filteredPosts =
    selectedCategory === "All" ? forumPosts : forumPosts.filter((post) => post.category === selectedCategory)

  return (
    <div className="space-y-6">
      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Button
            key={category}
            variant={selectedCategory === category ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory(category)}
          >
            {category}
          </Button>
        ))}
      </div>

      {/* New Post Button */}
      <Card>
        <CardContent className="p-4">
          {!showNewPost ? (
            <Button onClick={() => setShowNewPost(true)} className="w-full">
              Share your thoughts with the community
            </Button>
          ) : (
            <div className="space-y-4">
              <Textarea
                placeholder="What's on your mind? Share your yoga journey, ask questions, or offer tips..."
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                className="min-h-[100px]"
              />
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowNewPost(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    console.log("New post:", newPost)
                    setNewPost("")
                    setShowNewPost(false)
                  }}
                >
                  Post
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Forum Posts */}
      <div className="space-y-4">
        {filteredPosts.map((post) => (
          <Card key={post.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={post.author.avatar || "/placeholder.svg"} />
                    <AvatarFallback>
                      {post.author.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{post.author.name}</span>
                      <Badge variant="secondary" className="text-xs">
                        Level {post.author.level}
                      </Badge>
                      {post.author.badge && (
                        <Badge variant="outline" className="text-xs">
                          {post.author.badge}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                      <span>{post.timestamp}</span>
                      <span>•</span>
                      <span>{post.category}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-1">
                  {post.isPinned && <Pin className="w-4 h-4 text-primary" />}
                  {post.isHot && <Flame className="w-4 h-4 text-orange-500" />}
                  <Button variant="ghost" size="sm">
                    <MoreHorizontal className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            <CardContent className="pt-0">
              <h3 className="font-semibold text-lg mb-2">{post.title}</h3>
              <p className="text-muted-foreground mb-4 line-clamp-3">{post.content}</p>

              <div className="flex flex-wrap gap-1 mb-4">
                {post.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    #{tag}
                  </Badge>
                ))}
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-red-500">
                    <Heart className="w-4 h-4 mr-1" />
                    {post.likes}
                  </Button>
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-blue-500">
                    <MessageCircle className="w-4 h-4 mr-1" />
                    {post.replies}
                  </Button>
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-green-500">
                    <Share2 className="w-4 h-4 mr-1" />
                    Share
                  </Button>
                </div>
                <Button variant="outline" size="sm">
                  Read More
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
