"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Send, Users, Settings, Smile } from "lucide-react"

interface ChatMessage {
  id: string
  user: {
    name: string
    avatar?: string
    level: number
    isOnline: boolean
  }
  message: string
  timestamp: Date
  type: "message" | "join" | "leave" | "system"
}

const initialMessages: ChatMessage[] = [
  {
    id: "1",
    user: { name: "Sarah Chen", avatar: "/woman-doing-yoga.png", level: 28, isOnline: true },
    message: "Good morning everyone! Ready for today's practice?",
    timestamp: new Date(Date.now() - 300000),
    type: "message",
  },
  {
    id: "2",
    user: { name: "Marcus Johnson", avatar: "/man-meditation.png", level: 26, isOnline: true },
    message: "Looking forward to the arm balance workshop later",
    timestamp: new Date(Date.now() - 240000),
    type: "message",
  },
  {
    id: "3",
    user: { name: "System", level: 0, isOnline: true },
    message: "Priya Patel joined the chat",
    timestamp: new Date(Date.now() - 180000),
    type: "join",
  },
  {
    id: "4",
    user: { name: "Priya Patel", avatar: "/woman-namaste.png", level: 25, isOnline: true },
    message: "Hi everyone! Excited to connect with fellow yogis 🧘‍♀️",
    timestamp: new Date(Date.now() - 120000),
    type: "message",
  },
]

const onlineUsers = [
  { name: "Sarah Chen", avatar: "/woman-doing-yoga.png", level: 28 },
  { name: "Marcus Johnson", avatar: "/man-meditation.png", level: 26 },
  { name: "Priya Patel", avatar: "/woman-namaste.png", level: 25 },
  { name: "Alex Rivera", level: 24 },
  { name: "Emma Thompson", level: 23 },
  { name: "David Kim", level: 22 },
]

export function LiveChat() {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages)
  const [newMessage, setNewMessage] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Simulate incoming messages
  useEffect(() => {
    const interval = setInterval(() => {
      const randomMessages = [
        "Thanks for the tip on breathing techniques!",
        "Anyone joining the evening session?",
        "Love this community! So supportive 💚",
        "Just finished my morning practice, feeling great!",
        "Question: How long should I hold warrior pose?",
        "The meditation session yesterday was amazing",
      ]

      const randomUser = onlineUsers[Math.floor(Math.random() * onlineUsers.length)]
      const randomMessage = randomMessages[Math.floor(Math.random() * randomMessages.length)]

      if (Math.random() > 0.7) {
        // 30% chance of new message every 10 seconds
        const newMsg: ChatMessage = {
          id: Date.now().toString(),
          user: { ...randomUser, isOnline: true },
          message: randomMessage,
          timestamp: new Date(),
          type: "message",
        }
        setMessages((prev) => [...prev, newMsg])
      }
    }, 10000)

    return () => clearInterval(interval)
  }, [])

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const message: ChatMessage = {
        id: Date.now().toString(),
        user: { name: "You", level: 12, isOnline: true },
        message: newMessage,
        timestamp: new Date(),
        type: "message",
      }
      setMessages((prev) => [...prev, message])
      setNewMessage("")
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Main Chat */}
      <div className="lg:col-span-3">
        <Card className="h-[600px] flex flex-col">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <Users className="w-5 h-5" />
                <span>Community Chat</span>
                <Badge variant="secondary">{onlineUsers.length} online</Badge>
              </CardTitle>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>

          <CardContent className="flex-1 flex flex-col p-0">
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div key={message.id}>
                  {message.type === "join" || message.type === "leave" || message.type === "system" ? (
                    <div className="text-center text-xs text-muted-foreground py-1">{message.message}</div>
                  ) : (
                    <div
                      className={`flex space-x-3 ${message.user.name === "You" ? "flex-row-reverse space-x-reverse" : ""}`}
                    >
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={message.user.avatar || "/placeholder.svg"} />
                        <AvatarFallback className="text-xs">
                          {message.user.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div className={`flex-1 ${message.user.name === "You" ? "text-right" : ""}`}>
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="text-sm font-medium">{message.user.name}</span>
                          {message.user.level > 0 && (
                            <Badge variant="outline" className="text-xs">
                              L{message.user.level}
                            </Badge>
                          )}
                          <span className="text-xs text-muted-foreground">{formatTime(message.timestamp)}</span>
                        </div>
                        <div
                          className={`inline-block p-3 rounded-lg max-w-xs lg:max-w-md ${
                            message.user.name === "You" ? "bg-primary text-white" : "bg-muted"
                          }`}
                        >
                          <p className="text-sm">{message.message}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
              {isTyping && (
                <div className="flex space-x-3">
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className="text-xs">...</AvatarFallback>
                  </Avatar>
                  <div className="bg-muted p-3 rounded-lg">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                      <div
                        className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                        style={{ animationDelay: "0.1s" }}
                      ></div>
                      <div
                        className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                        style={{ animationDelay: "0.2s" }}
                      ></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <div className="border-t p-4">
              <div className="flex space-x-2">
                <Input
                  placeholder="Type your message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="flex-1"
                />
                <Button variant="ghost" size="sm">
                  <Smile className="w-4 h-4" />
                </Button>
                <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Online Users */}
      <div className="lg:col-span-1">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Online Now ({onlineUsers.length})</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="space-y-2 p-4">
              {onlineUsers.map((user, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div className="relative">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={user.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="text-xs">
                        {user.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{user.name}</div>
                    <div className="text-xs text-muted-foreground">Level {user.level}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
