"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Trophy, Users, Calendar, Target, Flame, Globe } from "lucide-react"

interface GlobalChallenge {
  id: string
  title: string
  description: string
  type: "community" | "individual" | "team"
  duration: string
  participants: number
  goal: number
  currentProgress: number
  reward: string
  difficulty: "easy" | "medium" | "hard"
  startDate: string
  endDate: string
  leaderboard: {
    rank: number
    name: string
    avatar?: string
    progress: number
  }[]
  isJoined: boolean
}

const globalChallenges: GlobalChallenge[] = [
  {
    id: "1",
    title: "Global Meditation Marathon",
    description: "Join yogis worldwide in a collective meditation challenge. Let's reach 1 million minutes together!",
    type: "community",
    duration: "30 days",
    participants: 12847,
    goal: 1000000,
    currentProgress: 678432,
    reward: "Exclusive Meditation Master badge",
    difficulty: "easy",
    startDate: "2025-01-01",
    endDate: "2025-01-31",
    leaderboard: [
      { rank: 1, name: "Sarah Chen", avatar: "/woman-doing-yoga.png", progress: 2340 },
      { rank: 2, name: "Marcus Johnson", avatar: "/man-meditation.png", progress: 2180 },
      { rank: 3, name: "Priya Patel", avatar: "/woman-namaste.png", progress: 1950 },
    ],
    isJoined: true,
  },
  {
    id: "2",
    title: "30-Day Pose Mastery",
    description: "Master a new yoga pose every day for 30 days. Perfect your practice with daily guidance.",
    type: "individual",
    duration: "30 days",
    participants: 8934,
    goal: 30,
    currentProgress: 18,
    reward: "Pose Master certification",
    difficulty: "medium",
    startDate: "2025-01-01",
    endDate: "2025-01-31",
    leaderboard: [
      { rank: 1, name: "Alex Rivera", progress: 28 },
      { rank: 2, name: "Emma Thompson", progress: 26 },
      { rank: 3, name: "David Kim", progress: 24 },
    ],
    isJoined: false,
  },
  {
    id: "3",
    title: "Team Flexibility Challenge",
    description: "Form teams of 5 and compete in flexibility challenges. Track your team's collective progress!",
    type: "team",
    duration: "14 days",
    participants: 2450,
    goal: 100,
    currentProgress: 67,
    reward: "Team Champion trophy",
    difficulty: "hard",
    startDate: "2025-01-15",
    endDate: "2025-01-29",
    leaderboard: [
      { rank: 1, name: "Flexibility Masters", progress: 89 },
      { rank: 2, name: "Zen Warriors", progress: 82 },
      { rank: 3, name: "Flow State", progress: 78 },
    ],
    isJoined: false,
  },
]

export function GlobalChallenges() {
  const [selectedChallenge, setSelectedChallenge] = useState<GlobalChallenge | null>(null)

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-100 text-green-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "hard":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "community":
        return <Globe className="w-4 h-4" />
      case "individual":
        return <Target className="w-4 h-4" />
      case "team":
        return <Users className="w-4 h-4" />
      default:
        return <Trophy className="w-4 h-4" />
    }
  }

  const handleJoinChallenge = (challengeId: string) => {
    console.log("Joining challenge:", challengeId)
    // In a real app, this would make an API call
  }

  return (
    <div className="space-y-6">
      {/* Active Challenges */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {globalChallenges.map((challenge) => (
          <Card key={challenge.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  {getTypeIcon(challenge.type)}
                  <CardTitle className="text-lg">{challenge.title}</CardTitle>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className={getDifficultyColor(challenge.difficulty)} variant="secondary">
                    {challenge.difficulty}
                  </Badge>
                  {challenge.isJoined && (
                    <Badge variant="default">
                      <Flame className="w-3 h-3 mr-1" />
                      Joined
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">{challenge.description}</p>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span>{challenge.duration}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span>{challenge.participants.toLocaleString()} joined</span>
                </div>
              </div>

              {/* Progress */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Global Progress</span>
                  <span>
                    {challenge.currentProgress.toLocaleString()} / {challenge.goal.toLocaleString()}
                  </span>
                </div>
                <Progress value={(challenge.currentProgress / challenge.goal) * 100} className="h-2" />
              </div>

              {/* Reward */}
              <div className="flex items-center space-x-2 p-3 bg-muted/50 rounded-lg">
                <Trophy className="w-4 h-4 text-yellow-500" />
                <span className="text-sm font-medium">Reward: {challenge.reward}</span>
              </div>

              {/* Top Performers */}
              <div className="space-y-2">
                <h4 className="text-sm font-medium">Top Performers</h4>
                <div className="space-y-1">
                  {challenge.leaderboard.slice(0, 3).map((entry) => (
                    <div key={entry.rank} className="flex items-center justify-between text-sm">
                      <div className="flex items-center space-x-2">
                        <span className="w-4 text-center font-medium">#{entry.rank}</span>
                        {entry.avatar && (
                          <Avatar className="w-5 h-5">
                            <AvatarImage src={entry.avatar || "/placeholder.svg"} />
                            <AvatarFallback className="text-xs">
                              {entry.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                        )}
                        <span>{entry.name}</span>
                      </div>
                      <span className="font-medium">{entry.progress.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-2">
                {challenge.isJoined ? (
                  <Button variant="outline" className="w-full bg-transparent">
                    View Progress
                  </Button>
                ) : (
                  <Button onClick={() => handleJoinChallenge(challenge.id)} className="w-full">
                    Join Challenge
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Challenge Stats */}
      <Card>
        <CardHeader>
          <CardTitle>Community Impact</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">25,231</div>
              <div className="text-sm text-muted-foreground">Active Participants</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">1.2M</div>
              <div className="text-sm text-muted-foreground">Minutes Meditated</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">847</div>
              <div className="text-sm text-muted-foreground">Poses Mastered</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">156</div>
              <div className="text-sm text-muted-foreground">Countries</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
