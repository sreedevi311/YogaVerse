"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

// Mock data generators
const generateHeartRateData = (days: number) => {
  const data = []
  const now = new Date()

  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(now)
    date.setDate(date.getDate() - i)

    data.push({
      date: date.toISOString().split("T")[0],
      time: date.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      resting: 65 + Math.random() * 10,
      active: 120 + Math.random() * 30,
      peak: 160 + Math.random() * 20,
    })
  }
  return data
}

const generateBreathingData = (days: number) => {
  const data = []
  const now = new Date()

  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(now)
    date.setDate(date.getDate() - i)

    data.push({
      date: date.toISOString().split("T")[0],
      time: date.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      rate: 14 + Math.random() * 6,
      depth: 70 + Math.random() * 30,
      rhythm: 80 + Math.random() * 20,
    })
  }
  return data
}

const generateStressData = (days: number) => {
  const data = []
  const now = new Date()

  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(now)
    date.setDate(date.getDate() - i)

    data.push({
      date: date.toISOString().split("T")[0],
      time: date.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      stress: Math.random() * 100,
      recovery: 60 + Math.random() * 40,
    })
  }
  return data
}

export function HealthCharts() {
  const [timeRange, setTimeRange] = useState<"daily" | "weekly" | "monthly">("weekly")
  const [heartRateData, setHeartRateData] = useState(generateHeartRateData(7))
  const [breathingData, setBreathingData] = useState(generateBreathingData(7))
  const [stressData, setStressData] = useState(generateStressData(7))

  useEffect(() => {
    const days = timeRange === "daily" ? 1 : timeRange === "weekly" ? 7 : 30
    setHeartRateData(generateHeartRateData(days))
    setBreathingData(generateBreathingData(days))
    setStressData(generateStressData(days))
  }, [timeRange])

  // Real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      if (timeRange === "daily") {
        // Update with more frequent data points for daily view
        setHeartRateData((prev) => [
          ...prev.slice(1),
          {
            ...prev[prev.length - 1],
            time: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
            resting: 65 + Math.random() * 10,
            active: 120 + Math.random() * 30,
            peak: 160 + Math.random() * 20,
          },
        ])
      }
    }, 5000)

    return () => clearInterval(interval)
  }, [timeRange])

  const stressDistribution = [
    { name: "Low Stress", value: 45, color: "#10b981" },
    { name: "Moderate", value: 35, color: "#f59e0b" },
    { name: "High Stress", value: 20, color: "#ef4444" },
  ]

  return (
    <div className="space-y-6">
      {/* Time Range Selector */}
      <Tabs value={timeRange} onValueChange={(value) => setTimeRange(value as any)}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="daily">Daily</TabsTrigger>
          <TabsTrigger value="weekly">Weekly</TabsTrigger>
          <TabsTrigger value="monthly">Monthly</TabsTrigger>
        </TabsList>

        <TabsContent value={timeRange} className="space-y-6">
          {/* Heart Rate Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Heart Rate Trends
                <div className="flex items-center space-x-4 text-sm">
                  <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span>Peak</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span>Active</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span>Resting</span>
                  </div>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={heartRateData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis domain={["dataMin - 10", "dataMax + 10"]} />
                  <Tooltip />
                  <Line type="monotone" dataKey="peak" stroke="#ef4444" strokeWidth={2} />
                  <Line type="monotone" dataKey="active" stroke="#3b82f6" strokeWidth={2} />
                  <Line type="monotone" dataKey="resting" stroke="#10b981" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Breathing Patterns */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Breathing Patterns</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <AreaChart data={breathingData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Area
                      type="monotone"
                      dataKey="rate"
                      stackId="1"
                      stroke="#8b5cf6"
                      fill="#8b5cf6"
                      fillOpacity={0.6}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Stress Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={stressDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {stressDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <div className="mt-4 space-y-2">
                  {stressDistribution.map((item, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                        <span>{item.name}</span>
                      </div>
                      <span className="font-medium">{item.value}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Stress Levels Over Time */}
          <Card>
            <CardHeader>
              <CardTitle>Stress & Recovery Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={stressData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="stress" fill="#f59e0b" name="Stress Level" />
                  <Bar dataKey="recovery" fill="#10b981" name="Recovery Score" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
