"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Download, Share2, Mail, FileText, BarChart3 } from "lucide-react"

export function ExportData() {
  const [exportFormat, setExportFormat] = useState("pdf")
  const [dateRange, setDateRange] = useState("last-30-days")
  const [selectedMetrics, setSelectedMetrics] = useState({
    heartRate: true,
    breathing: true,
    stress: true,
    sleep: false,
    activity: true,
  })

  const handleExport = () => {
    // Mock export functionality
    console.log("Exporting data:", { exportFormat, dateRange, selectedMetrics })
    // In a real app, this would generate and download the file
  }

  const handleShare = () => {
    // Mock share functionality
    console.log("Sharing health report")
  }

  const handleEmailReport = () => {
    // Mock email functionality
    console.log("Emailing health report")
  }

  return (
    <div className="space-y-6">
      {/* Export Options */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Download className="w-5 h-5" />
            <span>Export Health Data</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Export Format</label>
              <Select value={exportFormat} onValueChange={setExportFormat}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pdf">PDF Report</SelectItem>
                  <SelectItem value="csv">CSV Data</SelectItem>
                  <SelectItem value="json">JSON Data</SelectItem>
                  <SelectItem value="xlsx">Excel Spreadsheet</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Date Range</label>
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="last-7-days">Last 7 Days</SelectItem>
                  <SelectItem value="last-30-days">Last 30 Days</SelectItem>
                  <SelectItem value="last-3-months">Last 3 Months</SelectItem>
                  <SelectItem value="last-year">Last Year</SelectItem>
                  <SelectItem value="all-time">All Time</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-sm font-medium">Select Metrics to Include</label>
            <div className="grid grid-cols-2 gap-3">
              {Object.entries(selectedMetrics).map(([key, checked]) => (
                <div key={key} className="flex items-center space-x-2">
                  <Checkbox
                    id={key}
                    checked={checked}
                    onCheckedChange={(checked) =>
                      setSelectedMetrics((prev) => ({ ...prev, [key]: checked as boolean }))
                    }
                  />
                  <label htmlFor={key} className="text-sm capitalize">
                    {key === "heartRate" ? "Heart Rate" : key}
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div className="flex space-x-2 pt-4">
            <Button onClick={handleExport} className="flex-1">
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
            <Button onClick={handleShare} variant="outline">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
            <Button onClick={handleEmailReport} variant="outline">
              <Mail className="w-4 h-4 mr-2" />
              Email Report
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardContent className="p-6 text-center">
            <FileText className="w-8 h-8 mx-auto mb-2 text-primary" />
            <h3 className="font-medium mb-1">Weekly Report</h3>
            <p className="text-xs text-muted-foreground">Generate comprehensive weekly health summary</p>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardContent className="p-6 text-center">
            <BarChart3 className="w-8 h-8 mx-auto mb-2 text-primary" />
            <h3 className="font-medium mb-1">Progress Chart</h3>
            <p className="text-xs text-muted-foreground">Visual progress report for sharing</p>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-md transition-shadow">
          <CardContent className="p-6 text-center">
            <Share2 className="w-8 h-8 mx-auto mb-2 text-primary" />
            <h3 className="font-medium mb-1">Share with Doctor</h3>
            <p className="text-xs text-muted-foreground">Send health data to healthcare provider</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
