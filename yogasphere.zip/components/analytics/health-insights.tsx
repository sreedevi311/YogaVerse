"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, TrendingDown, Heart, Activity, Zap, Target, Award, AlertTriangle } from "lucide-react"

const insights = [
  {
    title: "Heart Rate Variability",
    value: "Excellent",
    trend: "up",
    change: "+12%",
    description: "Your HRV has improved significantly over the past week, indicating better recovery.",
    icon: Heart,
    color: "text-green-500",
  },
  {
    title: "Breathing Efficiency",
    value: "Good",
    trend: "up",
    change: "+8%",
    description: "Consistent breathing patterns during yoga sessions show improved technique.",
    icon: Activity,
    color: "text-blue-500",
  },
  {
    title: "Stress Management",
    value: "Needs Attention",
    trend: "down",
    change: "-5%",
    description: "Stress levels have increased. Consider more meditation and rest days.",
    icon: Zap,
    color: "text-yellow-500",
  },
]

const goals = [
  { name: "Weekly Practice", current: 4, target: 5, unit: "sessions" },
  { name: "Average Heart Rate", current: 72, target: 70, unit: "bpm" },
  { name: "Stress Reduction", current: 35, target: 25, unit: "%" },
  { name: "Sleep Quality", current: 7.8, target: 8.5, unit: "/10" },
]

const achievements = [
  { name: "7-Day Streak", description: "Practiced yoga for 7 consecutive days", earned: true },
  { name: "Heart Rate Master", description: "Maintained optimal heart rate for 30 sessions", earned: true },
  { name: "Stress Warrior", description: "Reduced stress levels by 20%", earned: false },
  { name: "Breathing Expert", description: "Perfect breathing rhythm for 10 sessions", earned: true },
]

export function HealthInsights() {
  return (
    <div className="space-y-6">
      {/* Key Insights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {insights.map((insight, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <insight.icon className={`w-5 h-5 ${insight.color}`} />
                  <h3 className="font-medium text-sm">{insight.title}</h3>
                </div>
                <div className="flex items-center space-x-1">
                  {insight.trend === "up" ? (
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-red-500" />
                  )}
                  <span className={`text-sm font-medium ${insight.trend === "up" ? "text-green-500" : "text-red-500"}`}>
                    {insight.change}
                  </span>
                </div>
              </div>
              <div className="space-y-2">
                <Badge
                  variant={
                    insight.value === "Excellent" ? "default" : insight.value === "Good" ? "secondary" : "destructive"
                  }
                >
                  {insight.value}
                </Badge>
                <p className="text-xs text-muted-foreground">{insight.description}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Goals Progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="w-5 h-5" />
            <span>Health Goals Progress</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {goals.map((goal, index) => (
            <div key={index} className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">{goal.name}</span>
                <span className="text-sm text-muted-foreground">
                  {goal.current} / {goal.target} {goal.unit}
                </span>
              </div>
              <Progress value={(goal.current / goal.target) * 100} className="h-2" />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Recent Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Award className="w-5 h-5" />
            <span>Achievements</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {achievements.map((achievement, index) => (
            <div key={index} className="flex items-center space-x-3 p-3 rounded-lg bg-muted/50">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  achievement.earned ? "bg-primary text-white" : "bg-gray-200 text-gray-400"
                }`}
              >
                <Award className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h4 className="font-medium text-sm">{achievement.name}</h4>
                <p className="text-xs text-muted-foreground">{achievement.description}</p>
              </div>
              {achievement.earned && <Badge variant="default">Earned</Badge>}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Health Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5" />
            <span>Personalized Recommendations</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h4 className="font-medium text-sm text-blue-900 mb-1">Optimize Recovery</h4>
            <p className="text-xs text-blue-700">
              Your heart rate variability suggests you need more recovery time. Try gentle yoga or meditation tomorrow.
            </p>
          </div>
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <h4 className="font-medium text-sm text-green-900 mb-1">Breathing Excellence</h4>
            <p className="text-xs text-green-700">
              Your breathing patterns are improving! Continue with pranayama exercises to maintain this progress.
            </p>
          </div>
          <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
            <h4 className="font-medium text-sm text-yellow-900 mb-1">Stress Management</h4>
            <p className="text-xs text-yellow-700">
              Consider adding 10 minutes of meditation before bed to help reduce evening stress levels.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
